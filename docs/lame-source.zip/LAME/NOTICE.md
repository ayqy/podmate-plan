# LAME MP3 encoder

This directory contains the LAME 4.0 encoder sources used by Podmate's iOS MP3 export. The version is recorded in `version.h`; the upstream project is <https://lame.sourceforge.io/>. The LGPL license text and upstream licensing note are included as `COPYING` and `LICENSE`.

The Podmate wrapper files `PodmateMP3.c` and `PodmateMP3.h` are distributed under the GNU Library General Public License version 2, or (at your option) any later version, as part of this library. See COPYING for the license and warranty disclaimer.

Podmate links this code as a separate static `libmp3lame.a`. Version-bound corresponding library sources, application object files and necessary resources for replacement/relinking are supplied at <https://ayqy.github.io/podmate-plan/relinking.html>. Library C source bytes remain unchanged; the build target and distribution materials are separate from the application source license.
