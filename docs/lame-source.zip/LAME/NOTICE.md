# LAME MP3 encoder

This directory contains the LAME 4.0 encoder sources used by Podmate's iOS MP3 export. The version is recorded in `version.h`; the upstream project is <https://lame.sourceforge.io/>. The LGPL license text and upstream licensing note are included as `COPYING` and `LICENSE`.

The current deliverable is source code and a simulator build. Before distributing a binary, the distributor must review and satisfy the applicable LGPL obligations, including notices, source availability, and replacement or relinking requirements. The Podmate wrapper is `PodmateMP3.c` and `PodmateMP3.h`.
