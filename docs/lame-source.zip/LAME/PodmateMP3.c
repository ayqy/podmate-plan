#include "PodmateMP3.h"
#include "lame.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct PodmateMP3Encoder {
    lame_global_flags *flags;
};

PodmateMP3Encoder *PodmateMP3Create(int sampleRate, int bitrateKbps,
                                   const uint8_t *coverPNG, int coverBytes) {
    return PodmateMP3CreateWithVoice(sampleRate, bitrateKbps, coverPNG, coverBytes, "original");
}

PodmateMP3Encoder *PodmateMP3CreateWithVoice(int sampleRate, int bitrateKbps,
                                   const uint8_t *coverPNG, int coverBytes, const char *humanVoicePreset) {
    if (sampleRate != 44100 || bitrateKbps < 96 || bitrateKbps > 320 ||
        !coverPNG || coverBytes <= 0 || coverBytes > 1048576 || !humanVoicePreset ||
        (strcmp(humanVoicePreset, "original") != 0 && strcmp(humanVoicePreset, "warm") != 0 &&
         strcmp(humanVoicePreset, "bright") != 0)) return NULL;
    PodmateMP3Encoder *encoder = calloc(1, sizeof(*encoder));
    if (!encoder) return NULL;
    encoder->flags = lame_init();
    if (!encoder->flags) { free(encoder); return NULL; }
    id3tag_init(encoder->flags);
    id3tag_v2_4_UTF8_only(encoder->flags);
    id3tag_set_title(encoder->flags, "Podmate audio program");
    char disclosure[160];
    snprintf(disclosure, sizeof(disclosure),
             "Contains AI-generated speech; Podmate; synthetic audio; human-voice-preset:%s;", humanVoicePreset);
    id3tag_set_comment(encoder->flags, disclosure);
    if (id3tag_set_albumart(encoder->flags, (const char *)coverPNG, (size_t)coverBytes) < 0) {
        PodmateMP3Destroy(encoder);
        return NULL;
    }
    if (lame_set_num_channels(encoder->flags, 2) < 0 ||
        lame_set_in_samplerate(encoder->flags, sampleRate) < 0 ||
        lame_set_brate(encoder->flags, bitrateKbps) < 0 ||
        lame_set_quality(encoder->flags, 3) < 0 ||
        lame_init_params(encoder->flags) < 0) {
        PodmateMP3Destroy(encoder);
        return NULL;
    }
    return encoder;
}

int PodmateMP3Encode(PodmateMP3Encoder *encoder, const int16_t *interleaved,
                     int frames, uint8_t *output, int capacity) {
    if (!encoder || !interleaved || !output || frames <= 0 || capacity <= 0) return -1;
    return lame_encode_buffer_interleaved(encoder->flags, (short int *)interleaved,
                                          frames, output, capacity);
}

int PodmateMP3Flush(PodmateMP3Encoder *encoder, uint8_t *output, int capacity) {
    if (!encoder || !output || capacity <= 0) return -1;
    return lame_encode_flush(encoder->flags, output, capacity);
}

void PodmateMP3Destroy(PodmateMP3Encoder *encoder) {
    if (!encoder) return;
    if (encoder->flags) lame_close(encoder->flags);
    free(encoder);
}
