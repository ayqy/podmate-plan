#ifndef PODMATE_MP3_H
#define PODMATE_MP3_H

#include <stdint.h>

typedef struct PodmateMP3Encoder PodmateMP3Encoder;

PodmateMP3Encoder *PodmateMP3Create(int sampleRate, int bitrateKbps,
                                   const uint8_t *coverPNG, int coverBytes);
PodmateMP3Encoder *PodmateMP3CreateWithVoice(int sampleRate, int bitrateKbps,
                                   const uint8_t *coverPNG, int coverBytes, const char *humanVoicePreset);
int PodmateMP3Encode(PodmateMP3Encoder *encoder, const int16_t *interleaved,
                     int frames, uint8_t *output, int capacity);
int PodmateMP3Flush(PodmateMP3Encoder *encoder, uint8_t *output, int capacity);
void PodmateMP3Destroy(PodmateMP3Encoder *encoder);

#endif
